/*------------------ BACKGROUND COLOR ------------------*/ 


const colorBtns = document.getElementsByClassName("colorBtn");
const body = document.body
const h2 = document.getElementById("title");

for (let colorBtn of colorBtns) {
    colorBtn.onclick = () => {
        body.style.backgroundColor = colorBtn.innerText;
        colorBtn.style.color = "white";
        colorBtn.style.backgroundColor = "black";
        colorBtn.style.padding = "15px";
        h2.innerText = colorBtn.innerHTML;
    }
}


/*------------------ LIGHT ON --- LIGHT OFF ------------------*/ 

const swichOn = document.getElementById("swichOn");
const swichOff = document.getElementById("swichOff");
const lightON =document.getElementById("lightOn")
const lightOFF =document.getElementById("lightOff")

swichOn.onclick = () => {
    lightOFF.style.display = "none"
    lightON.style.display = "block"
}

swichOff.onclick = () => {
    lightON.style.display = "none"
    lightOFF.style.display = "block"
}












/*------------------ COMPUTER --- PHONE ------------------*/ 

const phoneInfo = [{id:1, name:'Phone', price:'100 AZN'}];
const computerInfo = [{id:2, name:'Computer', price:'200 AZN'}];

const infoDetale = ["ID:", "Product Name:", "Price:"];

const producsInfoPhone = document.getElementById("infoPhone");
const producsInfoComputer = document.getElementById("infoComputer");


const pricePhone = document.getElementById("infoPrice");
const pricePhoneComp = document.getElementById("infoPriceComp");

infoDetale.forEach((detale) => {pricePhone.innerHTML += `<li>${detale}</li>`})
infoDetale.forEach((detale) => {pricePhoneComp.innerHTML += `<li>${detale}</li>`})



const showPhoneInfo = () => {
    phoneInfo.forEach((info) => {
    producsInfoPhone.innerHTML += 
    `<li>${info.id}</li>
     <li>${info.name}</li>
     <li>${info.price}</li>`
    });

}

showPhoneInfo()

const showComputerInfo = () => {
    computerInfo.forEach((info) => {
    producsInfoComputer.innerHTML += 
    `<li>${info.id}</li>
     <li>${info.name}</li>
     <li>${info.price}</li>`
    });

}

showComputerInfo()