const bGroundMode = document.querySelector("#containerMode");
const frontBuilding = document.querySelectorAll(".frontBuild");
const backBuilding = document.querySelectorAll("#backBuild");

const windows = document.querySelectorAll(".windows");
const btn = document.querySelector("#changeBtn");
const moon = document.querySelector(".fa-solid");

const thief = document.querySelector(".thief");

const streetLaps = document.querySelectorAll(".city-lights")



let isShow = false;

const changeToDarkMode = () => {
    if (isShow) {
        bGroundMode.classList.add("dark-mode");
        moon.classList.add("fa-moon");
        windows.forEach(building => building.classList.add("night-light"));
        frontBuilding.forEach(building => building.classList.add("frontSide-Dark"));
        backBuilding.forEach(building => building.classList.add("backSide-Dark"));
        thief.classList.remove("hidden");
        streetLaps.forEach(lamp => lamp.classList.remove("hidden"));
    } else {
        bGroundMode.classList.remove("dark-mode");
        moon.classList.remove("fa-moon");
        windows.forEach(building => building.classList.remove("night-light"));
        frontBuilding.forEach(building => building.classList.remove("frontSide-Dark"));
        backBuilding.forEach(building => building.classList.remove("backSide-Dark"));
        thief.classList.add("hidden");
        streetLaps.forEach(lamp => lamp.classList.add("hidden"));
    }
    
}
changeToDarkMode()




btn.onclick = () => {
    isShow = !isShow;
    changeToDarkMode()
}