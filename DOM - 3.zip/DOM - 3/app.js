const users = [
    {
      name: "Leanne",
      surname: "Graham",
      email: "leanne@example.com",
      phonenumber: "1-770-736-8031",
      city: "Gwenborough"
    },
    {
      name: "Ervin",
      surname: "Howell",
      email: "ervin@example.com",
      phonenumber: "010-692-6593",
      city: "Wisokyburgh"
    },
    {
      name: "Carmen",
      surname: "Beck",
      email: "carmen@example.com",
      phonenumber: "781-329-8637",
      city: "Meyersville"
    },
    {
      name: "Anna",
      surname: "Smith",
      email: "anna.smith@example.com",
      phonenumber: "1-800-555-1234",
      city: "Springfield"
    },
    {
      name: "John",
      surname: "Doe",
      email: "john.doe@example.com",
      phonenumber: "1-800-555-5678",
      city: "Centerville"
    },
    {
      name: "Olivia",
      surname: "Johnson",
      email: "olivia.johnson@example.com",
      phonenumber: "1-800-555-2345",
      city: "Lakeside"
    },
    {
      name: "Lucas",
      surname: "Miller",
      email: "lucas.miller@example.com",
      phonenumber: "1-800-555-6789",
      city: "Riverside"
    },
    {
      name: "Sophia",
      surname: "Davis",
      email: "sophia.davis@example.com",
      phonenumber: "1-800-555-7890",
      city: "Oakwood"
    },
    {
      name: "Michael",
      surname: "Wilson",
      email: "michael.wilson@example.com",
      phonenumber: "1-800-555-9876",
      city: "Greendale"
    },
    {
      name: "Emma",
      surname: "Taylor",
      email: "emma.taylor@example.com",
      phonenumber: "1-800-555-5432",
      city: "Mapleton"
    }
  ];

const userData = [{name:"Name", surname: "Surname", email: "Email", phone: "Phone Number", city: "City"}]


const tableHead = document.querySelector("#tHead");
const tableBody = document.querySelector("#tableBody");



const showUserData = () => {
    tableHead.innerHTML = "";
    userData.forEach((user) => {
    tableHead.innerHTML += 
           `<tr>
            <th>${user.name}</th>
            <th>${user.surname}</th>
            <th>${user.email}</th>
            <th>${user.phone}</th>
            <th>${user.city}</th>
            </tr>`
  });

  
};
showUserData()


const showUserName = (arr) => {
    tableBody.innerHTML = "";
    arr.forEach((info) => {
        tableBody.innerHTML += 
        `<tr>
        <td>${info.name}</td>
        <td>${info.surname}</td>
        <td>${info.email}</td>
        <td>${info.phonenumber}</td>
        <td>${info.city}</td>
        </tr>`
    });
    
};
showUserName(users);


const searchInp = document.querySelector(".searchInp");
const searchName = document.querySelector(".searchName");
const searchSurname = document.querySelector(".searchBySurname");
const searchEmail = document.querySelector(".searchByEmail");
const searchPhoneNum = document.querySelector(".searchByPhone");
const searchCity = document.querySelector(".searchByCity");
searchInp.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredInp = users.filter((info) => info.name.toLowerCase().includes(val) || info.surname.toLowerCase().includes(val) || info.email.toLowerCase().includes(val) || info.phonenumber.toLowerCase().includes(val) || info.city.toLowerCase().includes(val));
    showUserName(filteredInp);
}
searchName.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredName = users.filter((info) => info.name.toLowerCase().includes(val))
    showUserName(filteredName);
}
searchSurname.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredSurname = users.filter((info) => info.surname.toLowerCase().includes(val))
    showUserName(filteredSurname);
}
searchEmail.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredEmail = users.filter((info) => info.email.toLowerCase().includes(val))
    showUserName(filteredEmail);
}
searchPhoneNum.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredPhone = users.filter((info) => info.phonenumber.toLowerCase().includes(val))
    showUserName(filteredPhone);
}
searchCity.oninput = (e) => {
    const val = e.target.value.toLowerCase();
    const filteredCity = users.filter((info) => info.city.toLowerCase().includes(val))
    showUserName(filteredCity);
}