/*
Strings
1.İstifadəçidən ikirəqəmli ədəd daxil etməsini xahiş edin. Bu rəqəmi üçrəqəmli olana qədər, 7 artırın. Son dəyəri konsola çıxarın.

*/


// let num1 = +prompt("Enter number");
// const getNumber = () => {
//     for (let i = num1; i <= 106; i+=7)
//     console.log(i);
//     return num1
// }
//     getNumber()


// ------------------------------------------------------------------------------

/*

2.Konsola N dəfə «I know how to use cycles» mesajı çıxaran proqram yazın.
Proqram N ədədini istifadəçidən soruşur.


*/


// const cyclesMessage = "I know how to use cycles";
// let enterNumber = +prompt("enter number");

// const getCycles = () => {
//     for (let i = 1; i <= enterNumber; i++) 
//         // let message
//         document.write(`${cyclesMessage} </br>`);
        
// }

// getCycles()


// ------------------------------------------------------------------------------

/*

3.İstifadəçidən tam adı «AD SOYAD» formatında daxil etməyi xahiş edin. Tam adını konsola fərqli qaydada yəni «SOYAD AD» formatında çıxarın,


*/


// let userName = prompt("Enter your name");
// let lastName = prompt("Enter your last name");
// const getFullName = (userName, lastName) => {
//     let message = userName + lastName;
//     console.log(message);
//     return message
    
// }

// getFullName(lastName, userName)


// ------------------------------------------------------------------------------

/*

4.Telefon nömrəsini parametr kimi qəbul edən isvalidnumber() funksiyasını yazın. Telefon nömrəsi 11 rəqəmdən ibarət olduqda və +7 ilə başladıqda, funksiya true qaytarır.
*/


// let phoneNum = prompt('enter your phone number')


// const isValidNumber = () => {
//     let message = "";
//     if (phoneNum.length === 11) {
//         message = phoneNum
//     } else {
//         message = "not valid";
        
//     }
//     console.log(message);
//     return message
    
// }
// isValidNumber()

// ------------------------------------------------------------------------------

/*
5.Funksiya yazın.Arqument olaraq aldığı sözün içərisində rəqəmləri seçsin və geri qaytarsın.
Məsələn: "hell5o wor6ld" -> 56
getNumberFromString(number)

*/




// let messageFromSting = "H3ll0 W0RLD";

// const getNumberFromString = () => {
//     let numbStr = messageFromSting.replaceAll(/\D/g, '');            // chatgpt--> başqa yolunu bilmirəm.
//     console.log(numbStr);
//     return messageFromSting;
// }

// getNumberFromString();

// ------------------------------------------------------------------------------

/*
6.Remove all exclamation
Funksiya yazın.Arqument olaraq string alsın,sözün içərisindəki bütün nida işarələrini silsin və sözün sonuna bir ədəd nida işarəsi əlavə etsin.
məsələn:
He!llo! !!FE-25 // netice olmalıdır Hello FE-25!
*/

// let exclam = "He!llo! !!FE-25";
// const removeAllExclamation = () => {
//     let remExclam = exclam.replaceAll("!", "").padEnd(exclam.length - 3, "!");
//     console.log(remExclam);
    
// }

// removeAllExclamation()

// ------------------------------------------------------------------------------


/*
7.Funksiya yazın,qəbul etdiyi parametrin baş hərfini böyütsün və ekarana yazdırsın
*/

// const getFirstUpperCase = () => {
//     let univerName = "fine art univercity";
//     let showFirstLetter = univerName[0].toUpperCase()
//     console.log(showFirstLetter);
    
// }


// getFirstUpperCase()



// const getFirstUpperCase = () => {
//     let univerName = "fine art univercity";
//     let showFirstLetter = univerName.charAt(0).toUpperCase()
//     console.log(showFirstLetter);
    
// }


// getFirstUpperCase()



// ------------------------------------------------------------------------------


/*
8.Funksiya yazın,qəbul etdiyi parametrin bütün hərflərini böyütsün və ekarana yazdırsın
*/


// const getWordUpperCase = () => {
//     let msg = "i am going to write uppercase sentence";
//     let getMsg = msg.toUpperCase();
//     console.log(getMsg);
//     return getMsg;
    
// }
// getWordUpperCase()

// ------------------------------------------------------------------------------



/*
9.Funksiya yazın,qəbul etdiyi parametrin bütün hərflərini kiçiltsin və ekarana yazdırsın
*/

// let message10 = "HOW ARE YOU, JOHN?"
// const getLowerCase = () => {
//     let getMessage10 = message10.toLowerCase();
//     console.log(getMessage10);
//     return getMessage10
    
// }

// getLowerCase()

/*


// ------------------------------------------------------------------------------


10.Funksiya yaradin, ilk characterimizi deyisek: ilkHerfiDeyis(soz, ilkHerf)
ilkHerfiDeyis('Qara', "Y") // Yara

*/

// let message11 = "Qara";
// const ilkHerfiDeyis = () => {
//     let getMessage11 = message11.replace("Q", "Y");
//     console.log(getMessage11);
    
// }

// ilkHerfiDeyis()


// ------------------------------------------------------------------------------


/*

11. funksiya yazın ad və soyad alsın və aşağıdakı kimi nəticə versin
nameFormat(str) —> Ramin Mammadzada-=> M. Ramin

*/




// ------------------------------------------------------------------------------

/*

12. verify gmail address. (gmail addressleri sonu @gmail.com ile bitmelidir, abcdf@gmail.com meselen) //true
*/

// const emailAddress = "@gmail.com";
// let yourEmail = prompt("email")


// const getEmail = () => {
//     if (yourEmail.slice(-10) === emailAddress) {
//         console.log(true);
//     } else {
//         console.log(false);
//     }
// }

// getEmail();

// ------------------------------------------------------------------------------



/*
13. Funksiya yazın,aldığı paramterdə bütün hərflər böyükdürsə true deyilsə false qaytarsın
*/


// let writeSente = prompt()        //  ------------------>>>>>>>   olmadi
// const getWordUpperCase = () => {
//     if (writeSente === writeSente.toUpperCase()) {
//         console.log(true);
        
//     } else {
//         console.log(false);
        
//     }
// }

// ------------------------------------------------------------------------------





/*
14. Funksiya yazın.Cümlə alacaq parametr olaraq.Funksiya isə cümlənin ilk 5 simvolunu geri qaytaracaq
*/




// let sentenceW = prompt();

// const getFirstFiveLetter = () => {
//     let message1001 = sentenceW.slice(0,4)
//     console.log(message1001);
    
// }

// getFirstFiveLetter()


// ------------------------------------------------------------------------------

/*
15. Funksiya yazın.Parametr alsın.Sözün içərisində nəqədər boşluq varsa hamsı - işarəsi olsun
*/


// const replaceSpaces = () => {
//     let sentence = prompt();
//     let modify = sentence.replaceAll(" ", "-")
//     console.log(modify);
    
// }

// replaceSpaces()