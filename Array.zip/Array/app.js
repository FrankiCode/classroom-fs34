/* 
1. Üç qrup yoldaşının adlarından ibarət massiv yaradın; Başqa bir qrup yoldaşının adını massivin sonuna əlavə edin; İlk adı silin; Massivi konsola çıxarın.
*/


// const removeUserName = () => {
//     let addStudent = prompt("ad daxil edin")
//     let jetStudents = ["Rauf", "Entiqe", "Miri"];
//     let takeOff = jetStudents.splice(0,1);
//     jetStudents.push(addStudent)
//     console.log(`Çıxarılan ad ${takeOff}`);
//     console.log(`Əlavə edilən ad ${addStudent}`);
//     console.log(jetStudents);
// }
// removeUserName()


/*
2. Üç addan ibarət massiv yaradın. Massivin ikinci elementinin dəyərini “Classified” ilə əvəz edin. Massivi konsola çıxarın.
*/


// const createArr = () => {
//     let listArr = ["Vuqar", "Serxan", "Mirza"];
//     let changeUserName = listArr.splice(1).join(" Classified ");
//     let arrI = ""
//     arrI = changeUserName.split(" ").join(", ")                 
//     let arr = [];
//     arr.push(arrI)
//     console.log(listArr);
//     console.log(arr);
// }

// createArr()                 // Bunun, daha qısa yolu olmalı idi. Daha sonra gpt-də baxdın .... 




// let listArr = ["Vuqar", "Serxan", "Mirza"];
// listArr[1] = "Classified";
// console.log(listArr);






/*
3. Massiv verilib. "Episode 4: New Hope" kimi mesajları ardıcıl olaraq konsola çıxarın. Massiv elementlərin düzün.
let arr = ['New Hope', 'The Empire Strikes Back', 'Return of the Jdi'];
*/


// const getEpisode = () => {
//     let arr = ['New Hope', 'The Empire Strikes Back', 'Return of the Jdi'];
//     for ( let i = 0; i < arr.length; i++) {
//         console.log(`Episode ${i}: ${arr[i]}`);   // ------- >>> Epidose 1-dən başlada bilmədim. hər dəfə, sonuncuda undefined verdi
//         }
// }

// getEpisode()          // Yenə gpt-də suala cavab artardın




// let arr = ['New Hope', 'The Empire Strikes Back', 'Return of the Jdi'];
// let episodeList = [4,5,6];
// for (let i = 0; i < arr.length; i++) {
//     console.log(`Episode ${episodeList[i]}: ${arr[i]}`);
// }





/*

4.İstifadəçidən vergüllə ayrılmış beş ədədi daxil etməyi xahiş edin və onları massivdə saxlayın. 
İstifadəçidən beş ədəd elementi daxil etməyi tələb edən, onları massivə yazan və ən kiçik ədədi konsola çıxaran proqram yazın.

*/


// const getMinNumber = () => {
//     let arr = [];
//     for (let i = 1; i <= 3; i++) {
//         let num = +prompt("reqem daxil edin");
//         arr.push(num);
//     }
//     let minNum = Math.min(...arr)
//     console.log(minNum);
    
// }

// getMinNumber()




/*

5. Verilən mətn tip dəyərdəki vergülləri nöqtəli vergüllə əvəz edin. '32, 31, 34, 36, 31' mətni verilmişdir ,İçindəki vergülləri nöqtəli vergüllə əvəz edin.(Massivden istifadə ederek


*/


// let textNumber = "32, 31, 34, 36, 31";

// const getReplacePushArray = () => {
//     let arr = [];
//     let textChange = textNumber.replaceAll(",", ";");
//     arr.push(textChange)
//     console.log(arr);
// }

// getReplacePushArray();